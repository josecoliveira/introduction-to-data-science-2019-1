# icd-lista3
Lista 3 de ICD - 2019/1
